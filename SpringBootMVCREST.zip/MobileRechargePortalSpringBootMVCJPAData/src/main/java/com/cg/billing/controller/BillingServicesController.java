package com.cg.billing.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;
@Controller
public class BillingServicesController {
	@Autowired
	BillingServices billingServices;

	@RequestMapping("/registrationCustomer")
	public ModelAndView registerCustomer(@ModelAttribute Customer customer) {
		customer=billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("registrationSuccessPage","customer",customer);
	}
	@RequestMapping("/postpaidAccountOpen")
	public ModelAndView postpaidAccountOpen(@RequestParam int customerID,int planID) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		long mobileNo=billingServices.openPostpaidMobileAccount(customerID,planID);
		return new ModelAndView("postpaidAccountPage","mobileNo",mobileNo);
	}
	@RequestMapping("/generateBill")
	public ModelAndView generateBill(@RequestParam int customerID,long mobileNo,String billMonth,int noOfLocalSMS,int noOfStdSMS,int noOfLocalCalls,int noOfStdCalls,int internetDataUsageUnits) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException {
		double bill=billingServices.generateMonthlyMobileBill(customerID,mobileNo,billMonth,noOfLocalSMS,noOfStdSMS,noOfLocalCalls,noOfStdCalls,internetDataUsageUnits);
		return new ModelAndView("generateBillPage","bill",bill);
	}
	@RequestMapping("/customerDetails")
	public ModelAndView customerDetails(@RequestParam int customerID) throws CustomerDetailsNotFoundException {
		Customer customer=billingServices.getCustomerDetails(customerID);
		return new ModelAndView("customerDetailsPage","customer",customer);
	}
	@RequestMapping("/postpaidAccountDetail")
	public ModelAndView postpaidAccountDetail(@RequestParam int customerID,long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		PostpaidAccount postpaidAccount=billingServices.getPostPaidAccountDetails(customerID,mobileNo);
		return new ModelAndView("postpaidAccountDetailsPage","postpaidAccount",postpaidAccount);
	}
	@RequestMapping("/monthlyBill")
	public ModelAndView billDetails(@RequestParam int customerID,long mobileNo,String month) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		Bill bill=billingServices.getMobileBillDetails(customerID,mobileNo,month);
		return new ModelAndView("monthlyBillPage","bill",bill);
	}
	@RequestMapping("/changeMobilePlan")
	public ModelAndView changeMobilePlan(@RequestParam int customerID,long mobileNo,int planID) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException,PlanDetailsNotFoundException {
		billingServices. changePlan(customerID,mobileNo,planID);
		return new ModelAndView("changePlanPage","success","Your plan has been changed successfully");
	}
	@RequestMapping("/closePostpaidAccount")
	public ModelAndView closePostpaidAccount(@RequestParam int customerID,long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		billingServices.closeCustomerPostPaidAccount(customerID,mobileNo);
		return new ModelAndView("closeAccountPage","success","Your account has been closed successfully");
	}
	@RequestMapping("/deleteCustomer")
	public ModelAndView deleteCustomer(@RequestParam int customerID) throws CustomerDetailsNotFoundException {
		billingServices.removeCustomerDetails(customerID);
		return new ModelAndView("closeAccountPage","success","Customer is removed from system");
	}
	
}
