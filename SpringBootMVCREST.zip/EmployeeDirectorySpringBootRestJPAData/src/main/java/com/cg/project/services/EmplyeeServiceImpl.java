package com.cg.project.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.project.beans.Employee;
import com.cg.project.daoservices.EmployeeDao;
import com.cg.project.exceptions.EmplyeeDetailsNotFoundException;
@Component("emplyeeServices")
public class EmplyeeServiceImpl implements EmployeeService{
	@Autowired
    private EmployeeDao employeeDao;
	@Override
	public Employee acceptEmployeeDetails(Employee employee) {
		employee=employeeDao.save(employee);
		return employee;
	}
      
	@Override
	public Employee getEmployeeDetails(int empId) throws EmplyeeDetailsNotFoundException {
		return employeeDao.findById(empId).orElseThrow(()->new EmplyeeDetailsNotFoundException("Employee details not found for id"+empId));

	}

	@Override
	public List<Employee> getAllEmployeeDetails() {
		return employeeDao.findAll();
	}

	@Override
	public boolean removeEmployeeDetails(int employeeId) throws EmplyeeDetailsNotFoundException {
		employeeDao.delete(getEmployeeDetails(employeeId));
		return true;
	}

}
