package com.cg.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeDirectorySpringBootRestJpaDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeDirectorySpringBootRestJpaDataApplication.class, args);
	}

}
