package com.cg.project.services;

import java.util.List;

import com.cg.project.beans.Employee;
import com.cg.project.exceptions.EmplyeeDetailsNotFoundException;


public interface EmployeeService {
	Employee  acceptEmployeeDetails(Employee employee);
	 
	Employee getEmployeeDetails(int employeeId) throws EmplyeeDetailsNotFoundException;
	 List<Employee>getAllEmployeeDetails();
	 boolean removeEmployeeDetails(int employeeId) throws EmplyeeDetailsNotFoundException;

}
