package com.cg.project.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.project.exceptions.EmplyeeDetailsNotFoundException;
import com.cg.project.response.CustomeResponse;


@ControllerAdvice
public class EmplyeeExceptionAspect {
	@ExceptionHandler(EmplyeeDetailsNotFoundException.class)
	  public ResponseEntity<CustomeResponse> handleEmplyeeDetailsNotFoundException(Exception e) {
	     
		  CustomeResponse response = new CustomeResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
		  return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	  }
}
