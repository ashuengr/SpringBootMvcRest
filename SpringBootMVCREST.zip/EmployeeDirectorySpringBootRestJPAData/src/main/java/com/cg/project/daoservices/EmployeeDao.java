package com.cg.project.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.project.beans.Employee;

public interface EmployeeDao extends JpaRepository<Employee, Integer> {

}
