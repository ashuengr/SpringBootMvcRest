package com.cg.project.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.project.beans.Product;
import com.cg.project.daoservices.IProductRepo;
import com.cg.project.exceptions.ProductDetailsNotFoundException;

@Component("productServices")
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	IProductRepo iProductRepo;
	//creating Product
	@Override
	public Product acceptProductDetails(Product product) {
		product=iProductRepo.save(product);
		return product;
	}
	//Find Product using given ProductId
	@Override
	public Product getProductDetails(String id) throws ProductDetailsNotFoundException {
		return iProductRepo.findById(id).orElseThrow(()->new ProductDetailsNotFoundException("Product details not found for id"+id));

	}
	//View all product Details
	@Override
	public List<Product> getAllProductDetails() {
		return iProductRepo.findAll();
	}
	//Delete Product for given productId
	@Override
	public boolean removeProductDetails(String id) throws ProductDetailsNotFoundException {
		iProductRepo.delete(getProductDetails(id));
		return true;
	}
	 //updating product

	@Override
	 public Product updateProductDetails(Product product) {
		product=iProductRepo.save(product);
		return product;
	 }


}
