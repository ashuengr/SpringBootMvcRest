package com.cg.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.project.beans.Product;
import com.cg.project.exceptions.ProductDetailsNotFoundException;
import com.cg.project.services.IProductService;

@Controller
public class ProductController {
	
@Autowired
IProductService iproductService;

@RequestMapping(value= {"/acceptProductDetails"},method=RequestMethod.POST,
consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
public ResponseEntity<String> acceptEmployeeDetails(@ModelAttribute Product product){
	product = iproductService.acceptProductDetails(product);
return new ResponseEntity<>("Product details successfully added.\n Product ID: "+product.getId(),HttpStatus.OK);
}

@RequestMapping(value= {"/getProductDetails"},method=RequestMethod.GET,
produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
public ResponseEntity<Product> getProductDetailsRequestParam(@RequestParam String id) throws ProductDetailsNotFoundException{
	Product product = iproductService.getProductDetails(id);
return new ResponseEntity<Product>(product,HttpStatus.OK);
}

@RequestMapping(value= {"/getAllProductDetails"},method=RequestMethod.GET,
produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
public ResponseEntity<List<Product>> getProductDetailsPathParam(){
return new ResponseEntity<List<Product>>(iproductService.getAllProductDetails(),HttpStatus.OK);
}

@RequestMapping(value= {"/removeProductDetails/{id}"},method=RequestMethod.DELETE)								
public ResponseEntity<String> removeProductDetails(@PathVariable(value="id")String id) throws ProductDetailsNotFoundException{
	iproductService.removeProductDetails(id);
	return new ResponseEntity<>("Product details removed successfully",HttpStatus.OK);
}
}
