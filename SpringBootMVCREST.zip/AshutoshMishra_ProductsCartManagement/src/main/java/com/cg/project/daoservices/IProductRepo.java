package com.cg.project.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.project.beans.Product;

public interface IProductRepo extends JpaRepository<Product,String>{

}
