package com.cg.payroll;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgPayrollPortalSpringRestJpaData1Application {

	public static void main(String[] args) {
		SpringApplication.run(CgPayrollPortalSpringRestJpaData1Application.class, args);
	}

}
